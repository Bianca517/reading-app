package booksapp.root;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooksAppProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
