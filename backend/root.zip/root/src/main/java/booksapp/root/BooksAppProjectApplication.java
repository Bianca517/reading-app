package booksapp.root;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BooksAppProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BooksAppProjectApplication.class, args);
	}

}
